// ]:[::::::::::::::::::] :+: [::::::::::::::::::::]:[
// ]:[:::::::::]                         [:::::::::]:[
// ]:[:::            Ryan Branchaud             :::]:[
// ]:[:::         CS-405 Secure Coding          :::]:[
// ]:[:::       4-1 Activity: Exceptions        :::]:[
// ]:[:::               2/1/2025                :::]:[
// ]:[:::::::::]                         [:::::::::]:[
// ]:[::::::::::::::::::] :+: [::::::::::::::::::::]:[


// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

#include <exception>
#include <stdexcept>

// Creating the custom exception class for catching it explicitly in main
class cException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "This is my Custom Exception.";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // TODO: Throw any standard exception
    throw std::exception();

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    
    catch (const std::exception& caught)
    {
        std::cerr << "do_even_more_custom_application_logic() Exception Caught. " << caught.what() << std::endl;
    }
   
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw cException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0)
        throw std::overflow_error("Exception: Divide by Zero");
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }

    catch (const std::overflow_error& dbZero)
    {
        std::cerr << "do_division() Exception Caught. " << dbZero.what() << std::endl;
    }
}

int main()
{
    try
    {
        std::cout << "Ryan Branchaud's Exception Tests!" << std::endl;

        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.
        do_division();
        do_custom_application_logic();
    }

    catch (const cException& caught)
    {
        std::cerr << "main() Custom Exception Caught: " << caught.what() << std::endl;
    }

    catch (const std::exception& caught)
    {
        std::cerr << "Standard Exception Caught: " << caught.what() << std::endl;
    }

    catch (...)
    {
        std::cerr << "Unknown Exception Caught." << std::endl;
    }
   
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu