// ]:[::::::::::::::::::] :+: [::::::::::::::::::::]:[
// ]:[:::::::::]                         [:::::::::]:[
// ]:[:::            Ryan Branchaud             :::]:[
// ]:[:::         CS-405 Secure Coding          :::]:[
// ]:[:::    2-3 Activity: Buffer Overflow      :::]:[
// ]:[:::              1/20/2025                :::]:[
// ]:[:::::::::]                         [:::::::::]:[
// ]:[::::::::::::::::::] :+: [::::::::::::::::::::]:[

// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_number
	//  variable, and its position in the declaration. It must always be directly before the variable used for input.
	//  You must notify the user if they entered too much data.

	// STUDENT CODE: RB 1/20/25
	// Defining the buffer limit and setting it to 20. 
	const int BUFFER_LIMIT = 20;

	const std::string account_number = "CharlieBrown42";
	char user_input[20];
	std::cout << "Enter a value: ";

	// STUDENT CODE: RB 1/20/25
	// Accepts the user_input but prunes any values beyond the BUFFER_LIMIT
	std::cin.getline(user_input, BUFFER_LIMIT);

	// STUDENT CODE: RB 1/20/25
	// Output console statement when BUFFER_LIMIT is breached to inform users of the activity
	if (std::cin.gcount() == sizeof(user_input) - 1 && std::cin.peek() != '\n')
	{
		std::cout << "Your input exceeded the maximum character limit [20] and has been shortened." << std::endl;
	}

	std::cout << "You entered: " << user_input << std::endl;
	std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
